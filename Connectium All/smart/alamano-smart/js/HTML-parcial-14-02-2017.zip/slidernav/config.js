$(document).ready(function(){
	$('#slidernav').sliderNav();
});